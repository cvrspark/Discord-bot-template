import {guildId} from "../../../config.json"

export class denyRoles {
    static Ban = "1502339032628203616";
    static Unverify = "1502339091180687430";
    static Quarantine = "1502338922103967835";
    static NonAdmited = "1504138888053129296";
}
export class Logs {
    static EcoLogs = "1502344092632223906";
    static CoupleLogs = "1502344092632223906";
    static RoleLogs = "1502344092632223906";
    static RoomLogs = "1502344092632223906";
}
export class Channels {
    static LoveRoomCreate = "1513979693756579900";
}
export class StaffRoles {
}
export class Config {
    static GuildId = guildId;
    static LoveRole = "1513979347814322357"
}
export class AdminRoles {
    static Owner = "1502331396893577297"
    static CoOwner = "1502332853654917271"
    static TechAdmin = "1502332933543956520"
    static Global = "1502332933543956520"
    static Admin = "1502333004100534272"
}
export class Emojis {
    static Back = "<:Back:1513599880432451885>"
    static Bin = "<:Bin:1513599891270664222>"
    static Coins = "<:Coins:1513599905057210508>"
    static Color = "<:Color:1513599915597758674>"
    static Dislike = "<:Dislike:1513599925781397524>"
    static Dot = "<:Dot:1513599938628419814>"
    static EditText = "<:EditText:1513599947977658500>"
    static FullBack = "<:FullBack:1513599959088369715>"
    static FullNext = "<:FullNext:1513599968844316815>"
    static Heads = "<:Heads:1513599978885615697>"
    static Income = "<:Income:1513599993175605259>"
    static Like = "<:Like:1513600004676255985>"
    static MoveBack = "<:MoveBack:1513600015044710590>"
    static Next = "<:Next:1513600024901062766>"
    static Outcome = "<:Outcome:1513600035160592424>"
    static PlusMinus = "<:PlusMinus:1513600045541232760>"
    static Premium = "<:Premium:1513600055356166285>"
    static Shop = "<:Shop:1513600066005373019>"
    static Tails = "<:Tails:1513600076709236736>"
    static Top = "<:Top:1513600087396319422>"
    static User = "<:User:1513600097185693718>"
    static Image = "<:Image:1513600107537498163>"
}