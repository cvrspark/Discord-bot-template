import mongoose from "mongoose";
import config from "../../../../config.json";
import dns from 'node:dns';

dns.setServers(['8.8.8.8', '8.8.4.4']);
export async function startDatabase() {
	if (!config.dbToken) {
		return;
	}
	try {
		await mongoose.connect(config.dbToken);
		console.log("Database connected");
	} catch (err) {
		console.error("Database connection error:", err);
	}
}

