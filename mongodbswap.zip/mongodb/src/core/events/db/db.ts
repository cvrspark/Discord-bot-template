import mongoose from "mongoose";
import config from "../../../../config.json";
export async function startDatabase() {
	if (!config.db.host) {
		return;
	}
	try {
		await mongoose.connect(config.db.host);
		console.log("Database connected");
	} catch (err) {
		console.error("Database connection error:", err);
	}
}

